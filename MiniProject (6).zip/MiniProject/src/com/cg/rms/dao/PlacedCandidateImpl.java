package com.cg.rms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.rms.beans.Candidate;
import com.cg.rms.beans.CandidatePersonal;
import com.cg.rms.beans.CandidateQualifications;
import com.cg.rms.beans.CandidateWorkHistory;
import com.cg.rms.beans.PlacedCandidate;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.util.DBUtil;

public class PlacedCandidateImpl implements PlacedCandidateDAO {
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public ArrayList<PlacedCandidate> searchPlaced() throws RecruitmentException
	{	
		ArrayList<PlacedCandidate> candidateList=new ArrayList<PlacedCandidate>();
		try{
			con=DBUtil.getConn();
		st=con.createStatement();
		String query1="select * from placed_candidate";
		rs=st.executeQuery(query1);
		while(rs.next())
		{
			PlacedCandidate candidate=new PlacedCandidate(rs.getString(1),
					rs.getString(2),
					rs.getString(3)
					,rs.getString(4));
			candidateList.add(candidate);
		
		}
	}
		
	 catch (Exception e)
		{
		throw new RecruitmentException(e.getMessage());
		}
	finally 
			{
			try {
				con.close();
				rs.close();
				st.close();
				}
				catch (Exception e)
				{
						throw new RecruitmentException(e.getMessage());
				}
			}
		return candidateList;
 		}

}
