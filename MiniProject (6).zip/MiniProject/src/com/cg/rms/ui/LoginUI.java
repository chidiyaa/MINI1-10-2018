package com.cg.rms.ui;

public interface LoginUI {
	public void login();
	public void showMenu();
	public void signUp();
}
