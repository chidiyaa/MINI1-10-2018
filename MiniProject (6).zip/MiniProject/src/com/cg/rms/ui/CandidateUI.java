package com.cg.rms.ui;

import java.text.ParseException;

import com.cg.rms.exception.RecruitmentException;

public interface CandidateUI {
	public void applyJobs() throws RecruitmentException;
	public  void searchJobs() throws RecruitmentException;
	public  void modifyResume() throws ParseException, RecruitmentException ;
	public void addResume() throws RecruitmentException, ParseException;
	public String showCandidateMenu(String id);
}
